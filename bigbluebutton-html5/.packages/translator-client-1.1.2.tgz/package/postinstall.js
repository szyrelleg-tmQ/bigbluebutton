console.log('📦 [samplemodule] Running postinstall script...');

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

// Get __dirname equivalent in ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

function findProjectRoot(startDir) {
    let currentDir = startDir;

    while (currentDir !== path.dirname(currentDir)) {
        // Check if we're inside node_modules
        if (currentDir.includes('node_modules')) {
            currentDir = path.dirname(currentDir);
            continue;
        }

        // Check if package.json exists in this directory
        const packageJsonPath = path.join(currentDir, 'package.json');
        if (fs.existsSync(packageJsonPath)) {
            return currentDir;
        }

        currentDir = path.dirname(currentDir);
    }

    // Fallback to current working directory
    return process.cwd();
}

function detectProjectType(projectRoot) {
    const packageJsonPath = path.join(projectRoot, 'package.json');

    if (!fs.existsSync(packageJsonPath)) {
        return { type: 'unknown', staticDir: 'public' };
    }

    try {
        const packageJson = JSON.parse(fs.readFileSync(packageJsonPath, 'utf8'));
        const dependencies = { ...packageJson.dependencies, ...packageJson.devDependencies };

        // Check for React projects
        if (dependencies.react || dependencies['react-dom']) {
            return { type: 'react', staticDir: 'public' };
        }

        // Check for Next.js projects
        if (dependencies.next) {
            return { type: 'nextjs', staticDir: 'public' };
        }

        // Check for Express projects
        if (dependencies.express) {
            // Check if public directory already exists
            if (fs.existsSync(path.join(projectRoot, 'public'))) {
                return { type: 'express', staticDir: 'public' };
            }
            // Check for common static directories
            if (fs.existsSync(path.join(projectRoot, 'static'))) {
                return { type: 'express', staticDir: 'static' };
            }
            return { type: 'express', staticDir: 'public' };
        }

        // Check for Vue projects
        if (dependencies.vue || dependencies['@vue/cli-service']) {
            return { type: 'vue', staticDir: 'public' };
        }

        // Check for Angular projects
        if (dependencies['@angular/core']) {
            return { type: 'angular', staticDir: 'src/assets' };
        }

        // Default to Node.js project
        return { type: 'nodejs', staticDir: 'public' };

    } catch (error) {
        console.warn('⚠️  Could not parse package.json, using default settings');
        return { type: 'unknown', staticDir: 'public' };
    }
}

function copyDirectoryRecursive(source, target) {
    if (!fs.existsSync(target)) {
        fs.mkdirSync(target, { recursive: true });
    }

    const files = fs.readdirSync(source);
    let copiedCount = 0;

    for (const file of files) {
        const sourcePath = path.join(source, file);
        const targetPath = path.join(target, file);

        if (fs.statSync(sourcePath).isDirectory()) {
            copyDirectoryRecursive(sourcePath, targetPath);
        } else {
            fs.copyFileSync(sourcePath, targetPath);
            copiedCount++;
            console.log(`📄 Copied: ${file}`);
        }
    }

    return copiedCount;
}

function findTTSAssetsPath(projectRoot) {
    // Try to find the @tmq.paul/client-tts package
    const possiblePaths = [
        path.join(projectRoot, 'node_modules', '@tmq.paul', 'client-tts', 'dist', 'assets'),
        path.join(projectRoot, 'node_modules', '@tmq.paul', 'client-tts', 'assets'),
        path.join(projectRoot, 'node_modules', '@tmq.paul', 'client-tts', 'dist'),
    ];

    for (const assetsPath of possiblePaths) {
        if (fs.existsSync(assetsPath)) {
            console.log('🔍 Found TTS assets at:', assetsPath);
            return assetsPath;
        }
    }

    console.log('⚠️  Could not find @tmq.paul/client-tts assets in any of these locations:');
    possiblePaths.forEach(p => console.log('   -', p));
    return null;
}

try {
    // Find the actual project root (not inside node_modules)
    const projectRoot = findProjectRoot(__dirname);
    const projectInfo = detectProjectType(projectRoot);

    console.log('📍 Package directory:', __dirname);
    console.log('📍 Project root:', projectRoot);
    console.log('🔍 Detected project type:', projectInfo.type);
    console.log('📂 Target static directory:', projectInfo.staticDir);

    const staticDir = path.join(projectRoot, projectInfo.staticDir);
    const templateFile = path.join(__dirname, 'tts-sw.js.template');

    console.log('📍 Template file:', templateFile);
    console.log('📍 Target directory:', staticDir);

    // Ensure static directory exists
    if (!fs.existsSync(staticDir)) {
        console.log(`📂 ${projectInfo.staticDir}/ does not exist. Creating...`);
        fs.mkdirSync(staticDir, { recursive: true });
    } else {
        console.log(`📂 ${projectInfo.staticDir}/ directory already exists`);
    }

    // Try to find and copy TTS assets
    const ttsAssetsPath = findTTSAssetsPath(projectRoot);
    let copiedAssets = false;

    if (ttsAssetsPath) {
        console.log('🚀 Copying TTS assets from @tmq.paul/client-tts...');
        const copiedCount = copyDirectoryRecursive(ttsAssetsPath, staticDir);
        console.log(`✅ Copied ${copiedCount} TTS asset files to ${projectInfo.staticDir}/`);
        copiedAssets = true;
    } else {
        console.log('⚠️  @tmq.paul/client-tts package not found, creating service worker from template...');

        // Fallback: create service worker from template
        if (fs.existsSync(templateFile)) {
            const targetFile = path.join(staticDir, 'tts-sw.js');
            fs.copyFileSync(templateFile, targetFile);
            console.log(`✅ tts-sw.js created in ${projectInfo.staticDir}/`);
        } else {
            console.log('⚠️  Template file not found, skipping service worker creation');
        }
    }

    // Verify files were created
    const staticDirContents = fs.readdirSync(staticDir);
    console.log('📋 Files in static directory:', staticDirContents.join(', '));

    // Provide project-specific guidance
    switch (projectInfo.type) {
        case 'react':
            console.log('🚀 React project detected - TTS assets ready for use!');
            if (copiedAssets) {
                console.log('💡 Import TTS in your React components and the service worker will handle caching');
            }
            break;
        case 'nextjs':
            console.log('🚀 Next.js project detected - TTS assets ready for use!');
            if (copiedAssets) {
                console.log('💡 Assets are in public/ and will be served from the root path');
            }
            break;
        case 'express':
            console.log('🚀 Express project detected - serve static files from /' + projectInfo.staticDir);
            if (copiedAssets) {
                console.log('💡 Configure Express to serve static files: app.use(express.static("' + projectInfo.staticDir + '"))');
            }
            break;
        case 'vue':
            console.log('🚀 Vue project detected - TTS assets ready for use!');
            break;
        case 'angular':
            console.log('🚀 Angular project detected - TTS assets ready for use!');
            break;
        case 'nodejs':
            console.log('🚀 Node.js project detected - TTS assets ready for use!');
            break;
        default:
            console.log('🚀 TTS assets ready for use!');
    }

} catch (error) {
    console.error('❌ Postinstall script failed:', error.message);
    console.error('Stack trace:', error.stack);
    process.exit(1);
}