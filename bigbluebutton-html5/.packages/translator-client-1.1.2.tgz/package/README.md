# Translator Client

A JavaScript client for managing real-time video/audio rooms and bot-driven transcription/translation, built on [Daily.co](https://www.daily.co/) and [Pipecat AI](https://pipecat.ai/) services.

## Features

- Join and leave video/audio rooms
- Start a translation bot in a room
- Real-time transcription and translation callbacks
- Audio/video controls
- Participant management
- Language switching

## Installation

Install the package and its dependencies:

```bash
npm install @daily-co/daily-js @pipecat-ai/client-js @pipecat-ai/daily-transport
```

> **Note:** This client is intended for browser environments.

## Usage

### Import and Initialize

```js
import { getTranslatorClient } from './index'; // Adjust path as needed

const client = getTranslatorClient({
  baseUrl: 'http://localhost:7860/' // Optional, default shown
});
```

### Start a Bot

```js
await client.startBot('Alice', 'Spanish', 'room-123');
```

### Join a Room

```js
await client.joinRoom('https://your-domain.daily.co/room-123', 'Alice');
```

### Leave a Room

```js
await client.leaveRoom();
```

### Audio/Video Controls

```js
client.toggleAudio();
client.toggleVideo();
```

### Get Participants

```js
const participants = client.getParticipants();
```

### Set Transcription Callback

```js
client.setTranscriptionCallback((userText, botText) => {
  console.log('User:', userText, 'Bot:', botText);
});
```

### Change Language

```js
client.setLanguage('French');
```

### Event Handling

```js
client.on('joined-meeting', (event) => {
  console.log('Joined:', event);
});
client.off('joined-meeting', handler);
```

### Cleanup

```js
client.destroy();
```

## Configuration

- `baseUrl` (string): The base URL for the Pipecat AI backend. Defaults to `http://localhost:7860/`.
- The client expects to be run in a browser environment (checks for `window`).

## Dependencies

- `@daily-co/daily-js`
- `@pipecat-ai/client-js`
- `@pipecat-ai/daily-transport`

## Notes

- The client manages a singleton instance per configuration.
- For bot and transcription features, ensure your backend at `baseUrl` is running and accessible.
- Room URLs must be valid Daily.co room links. 