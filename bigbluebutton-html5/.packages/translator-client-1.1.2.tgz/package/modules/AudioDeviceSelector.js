/**
 * AudioDeviceSelector - Helper class for automatically selecting audio input and output devices
 * based on specific properties and preferences.
 */
import DeviceDetection from './DeviceDetection.js';

class AudioDeviceSelector {
    constructor() {
        this.devices = {
            audioInput: [],
            audioOutput: []
        };
        this.selectedDevices = {
            audioInput: null,
            audioOutput: null
        };
        this.isInitialized = false;
    }

    /**
     * Initialize the device selector and enumerate available devices
     * @returns {Promise<boolean>} True if initialization successful
     */
    async initialize({ audio = true, video = false }) {
        try {
            // Request permissions first using DeviceDetection
            const permissionsGranted = await DeviceDetection.requestPermissions({
                audio,
                video
            });
            if (!permissionsGranted) {
                throw new Error('Failed to get media device permissions');
            }

            // Enumerate devices
            await this.refreshDevices();
            this.isInitialized = true;
            return true;
        } catch (error) {
            console.error('Failed to initialize AudioDeviceSelector:', error);
            return false;
        }
    }

    /**
     * Refresh the list of available audio devices
     * @returns {Promise<void>}
     */
    async refreshDevices() {
        try {
            // Use DeviceDetection to get all devices
            const allDevices = await DeviceDetection.getAllDevices();

            // Use DeviceDetection format directly
            this.devices.audioInput = allDevices.microphones;
            this.devices.audioOutput = allDevices.speakers;

        } catch (error) {
            console.error('Error refreshing devices:', error);
        }
    }

    /**
     * Auto-select audio input device based on criteria
     * @param {Object} criteria - Selection criteria
     * @param {string[]} criteria.priorityKeywords - Keywords to prioritize (e.g., ['CABLE', 'VB-Audio', 'Microphone'])
     * @param {string[]} criteria.excludeKeywords - Keywords to exclude (e.g., ['default', 'system'])
     * @param {number} criteria.minChannels - Minimum number of channels required
     * @param {string} criteria.name - Exact device name to match
     * @returns {Object} Selected device
     */
    selectAudioInput(criteria = {}) {
        const {
            priorityKeywords = ['CABLE', 'VB-Audio', 'Virtual Cable', 'Microphone'],
            excludeKeywords = ['default', 'system', 'built-in'],
            name = null
        } = criteria;

        if (!this.devices.audioInput.length) {
            throw new Error('No audio input devices available');
        }

        // Score each device based on criteria
        const scoredDevices = this.devices.audioInput.map(device => {
            let score = 0;
            const deviceName = device.name.toLowerCase();

            // Exact name match (highest priority)
            if (name && device.name.toLowerCase() === name.toLowerCase()) {
                score += 1000;
            }

            // Priority keywords (high score)
            priorityKeywords.forEach(keyword => {
                if (deviceName.includes(keyword.toLowerCase())) {
                    score += 100;
                }
            });

            // Exclude keywords (negative score)
            excludeKeywords.forEach(keyword => {
                if (deviceName.includes(keyword.toLowerCase())) {
                    score -= 50;
                }
            });

            // Prefer devices with more channels (if we can detect them)
            if (deviceName.includes('stereo') || deviceName.includes('2ch')) {
                score += 20;
            }

            // Prefer devices with specific brands
            const brandKeywords = ['vb-audio', 'virtual cable', 'cable'];
            brandKeywords.forEach(brand => {
                if (deviceName.includes(brand)) {
                    score += 50;
                }
            });

            return { device, score };
        });

        // Sort by score (highest first)
        scoredDevices.sort((a, b) => b.score - a.score);

        // Select the highest scoring device
        const selectedDevice = scoredDevices[0]?.device || null;

        if (selectedDevice) {
            this.selectedDevices.audioInput = selectedDevice;
        } else {
            throw new Error('No suitable audio input device found');
        }

        // Check if exact name was requested but not found
        if (name && selectedDevice.name.toLowerCase() !== name.toLowerCase()) {
            throw new Error(`Audio input device with name "${name}" not found. Available devices: ${this.devices.audioInput.map(d => d.name).join(', ')}`);
        }

        return this.selectedDevices.audioInput;
    }

    /**
     * Auto-select audio output device based on criteria
     * @param {Object} criteria - Selection criteria
     * @param {string[]} criteria.priorityKeywords - Keywords to prioritize (e.g., ['CABLE', 'VB-Audio', 'Speakers'])
     * @param {string[]} criteria.excludeKeywords - Keywords to exclude (e.g., ['default', 'system'])
     * @param {string} criteria.name - Exact device name to match
     * @returns {Object} Selected device
     */
    selectAudioOutput(criteria = {}) {
        const {
            priorityKeywords = ['CABLE', 'VB-Audio', 'Virtual Cable', 'Speakers'],
            excludeKeywords = ['default', 'system', 'built-in'],
            name = null
        } = criteria;

        if (!this.devices.audioOutput.length) {
            throw new Error('No audio output devices available');
        }

        // Score each device based on criteria
        const scoredDevices = this.devices.audioOutput.map(device => {
            let score = 0;
            const deviceName = device.name.toLowerCase();
            const deviceId = device.id.toLowerCase();

            // Exact name match (highest priority)
            if (name && device.name.toLowerCase() === name.toLowerCase()) {
                score += 1000;
            }

            // Priority keywords (high score)
            priorityKeywords.forEach(keyword => {
                if (deviceName.includes(keyword.toLowerCase())) {
                    score += 100;
                }
            });

            // Exclude keywords (negative score)
            excludeKeywords.forEach(keyword => {
                if (deviceName.includes(keyword.toLowerCase())) {
                    score -= 50;
                }
            });

            // Prefer devices with specific brands
            const brandKeywords = ['vb-audio', 'virtual cable', 'cable'];
            brandKeywords.forEach(brand => {
                if (deviceName.includes(brand)) {
                    score += 50;
                }
            });

            return { device, score };
        });

        // Sort by score (highest first)
        scoredDevices.sort((a, b) => b.score - a.score);

        // Select the highest scoring device
        const selectedDevice = scoredDevices[0]?.device || null;

        if (selectedDevice) {
            this.selectedDevices.audioOutput = selectedDevice;
        } else {
            throw new Error('No suitable audio output device found');
        }

        // Check if exact name was requested but not found
        if (name && selectedDevice.name.toLowerCase() !== name.toLowerCase()) {
            throw new Error(`Audio output device with name "${name}" not found. Available devices: ${this.devices.audioOutput.map(d => d.name).join(', ')}`);
        }

        return this.selectedDevices.audioOutput;
    }

    /**
     * Auto-select both input and output devices
     * @param {Object} inputCriteria - Criteria for input device selection
     * @param {Object} outputCriteria - Criteria for output device selection
     * @returns {Object} Object containing selected input and output devices
     */
    selectDevices(inputCriteria = {}, outputCriteria = {}) {
        const inputDevice = this.selectAudioInput(inputCriteria);
        const outputDevice = this.selectAudioOutput(outputCriteria);

        return {
            input: inputDevice,
            output: outputDevice
        };
    }

    /**
     * Apply selected devices to audio elements
     * @param {HTMLAudioElement} audioElement - Audio element to configure
     * @param {string} deviceType - 'input' or 'output'
     * @returns {Promise<boolean>} True if successful
     */
    async applyDeviceToElement(audioElement, deviceType) {
        if (!audioElement) return false;

        const selectedDevice = this.selectedDevices[`audio${deviceType.charAt(0).toUpperCase() + deviceType.slice(1)}`];
        if (!selectedDevice) return false;

        try {
            if (deviceType === 'input') {
                // For input devices, we need to get user media with the specific device
                const stream = await navigator.mediaDevices.getUserMedia({
                    audio: {
                        deviceId: { exact: selectedDevice.id }
                    }
                });
                audioElement.srcObject = stream;
            } else if (deviceType === 'output') {
                // For output devices, we can set the sink (if supported)
                if (audioElement.setSinkId) {
                    await audioElement.setSinkId(selectedDevice.id);
                }
            }
            return true;
        } catch (error) {
            console.error(`Error applying ${deviceType} device:`, error);
            return false;
        }
    }

    /**
     * Get all available devices
     * @returns {Object} Object containing input and output devices
     */
    getAvailableDevices() {
        return {
            input: [...this.devices.audioInput],
            output: [...this.devices.audioOutput]
        };
    }

    /**
     * Get currently selected devices
     * @returns {Object} Object containing selected input and output devices
     */
    getSelectedDevices() {
        return {
            input: this.selectedDevices.audioInput,
            output: this.selectedDevices.audioOutput
        };
    }

    /**
     * Test audio device by playing a test tone
     * @param {string} deviceType - 'input' or 'output'
     * @param {number} duration - Duration in milliseconds
     * @returns {Promise<boolean>} True if test successful
     */
    async testDevice(deviceType, duration = 1000) {
        try {
            if (deviceType === 'input') {
                // Test input device by recording audio
                const stream = await navigator.mediaDevices.getUserMedia({
                    audio: {
                        deviceId: this.selectedDevices.audioInput?.id ?
                            { exact: this.selectedDevices.audioInput.id } : undefined
                    }
                });

                const mediaRecorder = new MediaRecorder(stream);
                const chunks = [];

                return new Promise((resolve) => {
                    mediaRecorder.ondataavailable = (e) => chunks.push(e.data);
                    mediaRecorder.onstop = () => {
                        stream.getTracks().forEach(track => track.stop());
                        resolve(chunks.length > 0);
                    };

                    mediaRecorder.start();
                    setTimeout(() => mediaRecorder.stop(), duration);
                });
            } else if (deviceType === 'output') {
                // Test output device by playing a test tone
                const audioContext = new (window.AudioContext || window.webkitAudioContext)();
                const oscillator = audioContext.createOscillator();
                const gainNode = audioContext.createGain();

                oscillator.connect(gainNode);
                gainNode.connect(audioContext.destination);

                oscillator.frequency.setValueAtTime(440, audioContext.currentTime);
                gainNode.gain.setValueAtTime(0.1, audioContext.currentTime);

                oscillator.start();
                oscillator.stop(audioContext.currentTime + duration / 1000);

                return new Promise((resolve) => {
                    setTimeout(() => {
                        audioContext.close();
                        resolve(true);
                    }, duration);
                });
            }
        } catch (error) {
            console.error(`Error testing ${deviceType} device:`, error);
            return false;
        }
    }

    /**
     * Clean up resources
     */
    cleanup() {
        this.devices = { audioInput: [], audioOutput: [] };
        this.selectedDevices = { audioInput: null, audioOutput: null };
        this.isInitialized = false;
    }

    /**
     * Listen for device changes and automatically refresh device list
     * @param {Function} callback Optional callback to call when devices change
     * @returns {Function} Function to remove the listener
     */
    onDeviceChange(callback) {
        const handleDeviceChange = async () => {
            await this.refreshDevices();
            if (callback) {
                callback(this.getAvailableDevices());
            }
        };

        return DeviceDetection.onDeviceChange(handleDeviceChange);
    }
}

// Export singleton instance
let audioDeviceSelectorInstance = null;

export function getAudioDeviceSelector() {
    if (!audioDeviceSelectorInstance) {
        audioDeviceSelectorInstance = new AudioDeviceSelector();
    }
    return audioDeviceSelectorInstance;
}

export function resetAudioDeviceSelector() {
    if (audioDeviceSelectorInstance) {
        audioDeviceSelectorInstance.cleanup();
    }
    audioDeviceSelectorInstance = null;
}

/**
 * Virtual Cable Device Selector - Wrapper function for selecting virtual cable devices
 * @param {string} inputName - Exact name of the input device
 * @param {string} outputName - Exact name of the output device
 * @returns {Promise<Object>} Object containing selected input and output devices
 */
export async function selectVirtualCableDevices(inputName, outputName, { audio = true, video = false }) {
    const deviceSelector = getAudioDeviceSelector();
    await deviceSelector.initialize({
        audio,
        video
    });

    return deviceSelector.selectDevices(
        { name: inputName },
        { name: outputName }
    );
}

export default AudioDeviceSelector; 