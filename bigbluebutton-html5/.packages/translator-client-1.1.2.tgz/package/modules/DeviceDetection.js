/**
 * Device Detection Utility
 * Uses Web Media API to detect available audio/video devices
 */

class DeviceDetection {
    /**
     * Get all available audio input devices (microphones)
     * @returns {Promise<Array>} Array of microphone devices
     */
    static async getMicrophones() {
        try {
            const devices = await navigator.mediaDevices.enumerateDevices();
            const audioInputs = devices.filter(device => device.kind === 'audioinput');

            return audioInputs.map((device, index) => ({
                id: device.deviceId,
                name: device.label || `Microphone ${index + 1}`,
                isSelected: index === 0 // First device is selected by default
            }));
        } catch (error) {
            console.error('Error getting microphones:', error);
            return [{ id: 'default', name: 'Default Microphone', isSelected: true }];
        }
    }

    /**
     * Get all available video input devices (cameras)
     * @returns {Promise<Array>} Array of camera devices
     */
    static async getCameras() {
        try {
            const devices = await navigator.mediaDevices.enumerateDevices();
            const videoInputs = devices.filter(device => device.kind === 'videoinput');

            return videoInputs.map((device, index) => ({
                id: device.deviceId,
                name: device.label || `Camera ${index + 1}`,
                isSelected: index === 0 // First device is selected by default
            }));
        } catch (error) {
            console.error('Error getting cameras:', error);
            return [{ id: 'default', name: 'Default Camera', isSelected: true }];
        }
    }

    /**
     * Get all available audio output devices (speakers)
     * Note: Audio output device enumeration is not widely supported
     * @returns {Promise<Array>} Array of speaker devices
     */
    static async getSpeakers() {
        try {
            // Check if audio output device selection is supported
            if ('setSinkId' in HTMLAudioElement.prototype) {
                const devices = await navigator.mediaDevices.enumerateDevices();
                const audioOutputs = devices.filter(device => device.kind === 'audiooutput');

                return audioOutputs.map((device, index) => ({
                    id: device.deviceId,
                    name: device.label || `Speaker ${index + 1}`,
                    isSelected: index === 0
                }));
            } else {
                // Fallback for browsers that don't support audio output enumeration
                return [{ id: 'default', name: 'Default Speaker', isSelected: true }];
            }
        } catch (error) {
            console.error('Error getting speakers:', error);
            return [{ id: 'default', name: 'Default Speaker', isSelected: true }];
        }
    }

    /**
     * Request permission to access media devices
     * This is required before device enumeration works properly
     * @returns {Promise<boolean>} True if permission granted
     */
    static async requestPermissions({ video = true, audio = true }) {
        try {
            // Request both audio and video permissions
            const stream = await navigator.mediaDevices.getUserMedia({
                audio,
                video
            });

            // Stop the stream immediately after getting permission
            stream.getTracks().forEach(track => track.stop());

            return true;
        } catch (error) {
            console.error('Error requesting permissions:', error);
            return false;
        }
    }

    /**
     * Listen for device changes and call the callback
     * @param {Function} callback Function to call when devices change
     * @returns {Function} Function to remove the listener
     */
    static onDeviceChange(callback) {
        const handleDeviceChange = () => {
            callback();
        };

        navigator.mediaDevices.addEventListener('devicechange', handleDeviceChange);

        // Return function to remove listener
        return () => {
            navigator.mediaDevices.removeEventListener('devicechange', handleDeviceChange);
        };
    }

    /**
     * Get all devices at once
     * @returns {Promise<Object>} Object with microphones, cameras, and speakers
     */
    static async getAllDevices() {
        const [microphones, cameras, speakers] = await Promise.all([
            this.getMicrophones(),
            this.getCameras(),
            this.getSpeakers()
        ]);

        return {
            microphones,
            cameras,
            speakers
        };
    }
}

export default DeviceDetection; 