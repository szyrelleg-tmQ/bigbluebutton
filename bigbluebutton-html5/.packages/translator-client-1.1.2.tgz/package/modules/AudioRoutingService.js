class AudioRoutingService {
    constructor() {
        this.audioRefs = new Map(); // Map participantId -> audio element
        this.isInitialized = false;
        this.currentLocalUserName = null;
        this.duckedParticipants = new Set();
    }

    // Helper function to check if participant is a bot
    isBot(userName) {
        return userName && userName.includes('bot-');
    }

    // Helper function to check if bot belongs to current local user
    isBotForLocalUser(botUserName, localUserName) {
        if (!this.isBot(botUserName) || !localUserName) return false;
        // Extract the guest part from bot name (remove 'bot-' prefix)
        const botGuestPart = botUserName.replace('bot-', '');
        return botGuestPart === localUserName;
    }

    // Filter participants for current user
    filterParticipants(allParticipants, currentUserName) {
        this.currentLocalUserName = currentUserName;

        const filtered = {
            local: allParticipants.find(p => p.local === true),
            remote: allParticipants.find(p =>
                !p.local && !this.isBot(p.user_name)
            ),
            botLocal: allParticipants.find(p =>
                this.isBot(p.user_name) &&
                this.isBotForLocalUser(p.user_name, currentUserName)
            ),
            botRemote: allParticipants.find(p =>
                this.isBot(p.user_name) &&
                !this.isBotForLocalUser(p.user_name, currentUserName)
            ),
            all: allParticipants
        };

        return filtered;
    }

    // Register audio element for a participant
    registerAudioElement(participantId, audioElement) {
        if (audioElement) {
            this.audioRefs.set(participantId, audioElement);
        }
    }

    // Unregister audio element for a participant
    unregisterAudioElement(participantId) {
        this.audioRefs.delete(participantId);
    }

    // Apply audio track to element if track changed
    async applyAudioTrack(participantId, audioTrack, audioElement) {
        if (!audioElement || !audioTrack) return false;

        try {
            // Check if we need to update the track
            const currentStream = audioElement.srcObject;
            const currentTracks = currentStream ? currentStream.getTracks() : [];
            const hasSameTrack = currentTracks.some(track => track.id === audioTrack.id);

            if (!hasSameTrack) {
                // Update with new track
                const newStream = new MediaStream([audioTrack]);
                audioElement.srcObject = newStream;
                return true; // Track was updated
            }
            return false; // No update needed
        } catch (error) {
            console.error('Error applying audio track:', error);
            return false;
        }
    }

    // Handle audio ducking when bots speak
    handleAudioDucking(participants) {
        if (!participants.botLocal || !participants.remote) return;

        const botLocalAudio = participants.botLocal.tracks?.audio;
        const botIsSpeaking = botLocalAudio && botLocalAudio.state === 'playable';

        // Get remote user audio element
        const remoteAudioElement = this.audioRefs.get(participants.remote.session_id);

        if (remoteAudioElement) {
            if (botIsSpeaking) {
                // Duck remote audio when bot speaks
                remoteAudioElement.volume = 0.1;
                this.duckedParticipants.add(participants.remote.session_id);
            } else {
                // Restore remote audio when bot stops
                remoteAudioElement.volume = 0.7;
                this.duckedParticipants.delete(participants.remote.session_id);
            }
        }
    }

    // Setup audio for participants based on routing rules
    async setupAudioRouting(participants) {
        const promises = [];

        // Setup remote user audio (heard by local user, can be ducked)
        if (participants.remote && participants.remote.tracks.audio) {
            const audioElement = this.audioRefs.get(participants.remote.session_id);
            if (audioElement) {
                const updated = await this.applyAudioTrack(
                    participants.remote.session_id,
                    participants.remote.tracks.audio.persistentTrack || participants.remote.tracks.audio.track,
                    audioElement
                );
                if (updated) {
                    audioElement.volume = 0.7; // Default volume
                    audioElement.muted = false;
                }
            }
        }

        // Setup bot-local audio (only heard by local user)
        if (participants.botLocal && participants.botLocal.tracks.audio) {
            const audioElement = this.audioRefs.get(participants.botLocal.session_id);
            if (audioElement) {
                await this.applyAudioTrack(
                    participants.botLocal.session_id,
                    participants.botLocal.tracks.audio.persistentTrack || participants.botLocal.tracks.audio.track,
                    audioElement
                );
                audioElement.volume = 1.0; // Full volume for bot responses
                audioElement.muted = false;
            }
        }

        // IMPORTANT: Bot-Remote audio should be muted for local user
        // This ensures audio isolation - each user only hears their own bot
        if (participants.botRemote && participants.botRemote.tracks.audio) {
            const audioElement = this.audioRefs.get(participants.botRemote.session_id);
            if (audioElement) {
                // Mute the Bot-Remote audio for local user
                audioElement.volume = 0;
                audioElement.muted = true;
            }
        }

        // Apply audio ducking
        this.handleAudioDucking(participants);

        return Promise.all(promises);
    }

    // Clean up audio elements
    cleanup() {
        this.audioRefs.forEach((audioElement, participantId) => {
            if (audioElement && audioElement.parentNode) {
                audioElement.parentNode.removeChild(audioElement);
            }
        });
        this.audioRefs.clear();
        this.duckedParticipants.clear();
        this.isInitialized = false;
        this.currentLocalUserName = null;
    }

    // Get current audio state for debugging
    getAudioState() {
        return {
            registeredElements: Array.from(this.audioRefs.keys()),
            duckedParticipants: Array.from(this.duckedParticipants),
            currentLocalUserName: this.currentLocalUserName
        };
    }
}

// Export singleton instance
let audioRoutingServiceInstance = null;

export function getAudioRoutingService() {
    if (!audioRoutingServiceInstance) {
        audioRoutingServiceInstance = new AudioRoutingService();
    }
    return audioRoutingServiceInstance;
}

export function resetAudioRoutingService() {
    if (audioRoutingServiceInstance) {
        audioRoutingServiceInstance.cleanup();
    }
    audioRoutingServiceInstance = null;
}

export default AudioRoutingService; 