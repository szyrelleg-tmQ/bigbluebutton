import { Logger } from "@tmq/logger";
import { EventEmitter } from "events";
import { PiperTTSProvider } from "./tts/piper.js";
import { WebSpeechTTSProvider } from "./tts/webspeech.js";
import { WebSpeechSTTProvider } from "./stt/webspeech.js";
import { GoogleWebTranslateProvider } from "./translate/googleWeb.js";


const TTS_PROVIDERS = {
    GOOGLE: "google",
    PIPER: "piper",
    WEB_SPEECH: "webspeech",
};
const STT_PROVIDERS = {
    WEB_SPEECH: "webspeech",
};
const TRANSLATION_PROVIDERS = {
    GOOGLE_WEB: "google-web",
};


export class ClientProviders extends EventEmitter {
    #config = {
        configUrl: "",
    };
    #tts = null;
    #stt = null;
    #translation = null;
    #pipeline = [];
    constructor(config) {
        super();
        this.#config = config;
        this.runPipeline();
    }
    /**
     * @returns {import("./tts/template").TTSProvider}
     */
    get TTS() { return this.#tts; }
    /**
     * @returns {import("./stt/template").STTProvider}
     */
    get STT() { return this.#stt; }
    /**
     * @returns {import("./translate/template").TranslateProvider}
     */
    get Translation() { return this.#translation; }
    /**
     * @returns {Promise<void>}
     */
    async initTTSProviders(config) {
        const provider = config.default_provider;
        switch (provider) {
            case TTS_PROVIDERS.PIPER:
                this.#tts = new PiperTTSProvider();
                break;
            case TTS_PROVIDERS.WEB_SPEECH:
                this.#tts = new WebSpeechTTSProvider();
                break;
            default:
                throw new Error(`Unsupported TTS provider: ${provider}`);
        }
        if (this.#tts) {
            await this.TTS.initialize();
        }
    }
    /**
     * @returns {Promise<void>}
     */
    async initSTTProviders(config) {
        const provider = config.default_provider;
        switch (provider) {
            case STT_PROVIDERS.WEB_SPEECH:
                this.#stt = new WebSpeechSTTProvider();
                break;
            case STT_PROVIDERS.GOOGLE_WEB:
                // TODO: Implement Google Web STT provider
                throw new Error(`Google Web STT provider not yet implemented`);
            default:
                throw new Error(`Unsupported STT provider: ${provider}`);
        }
        if (this.#stt) {
            await this.STT.initialize();
        }
    }
    /**
     * @returns {Promise<void>}
     */
    async initTranslationProviders(config) {
        const provider = config.default_provider;
        switch (provider) {
            case TRANSLATION_PROVIDERS.GOOGLE_WEB:
                this.#translation = new GoogleWebTranslateProvider();
                break;
            default:
                throw new Error(`Unsupported translation provider: ${provider}`);
        }
        if (this.#translation) {
            await this.Translation.initialize();
        }
    }
    async fetchConfig() {
        try {
            if (!this.#config.configUrl) {
                throw new Error("Config URL is required");
            }
            const response = await fetch(this.#config.configUrl);
            const data = await response.json();
            return data;
        } catch (error) {
            const msg = error.message || error.reason || error.stack || "Unknown error";
            Logger.error(`Failed to fetch config: ${msg}`);
            return null;
        }
    }
    on(event, listener) {
        const listeners = this.listeners(event);
        if (listeners.length > 0) {
            Logger.warn(`Event ${event} already has ${listeners.length} listeners`);
        }
        if (listeners.length === 0) {
            super.on(event, listener);
        }
    }
    async runPipeline() {
        try {
            const config = await this.fetchConfig();
            if (!config || !config.settings) {
                throw new Error("Failed to fetch config or config is invalid");
            }
            this.#pipeline = [
                this.initTTSProviders(config.settings.tts_providers),
                this.initSTTProviders(config.settings.stt_providers),
                this.initTranslationProviders(config.settings.translation_providers),
            ];
            await Promise.all(this.#pipeline);
            this.emit("pipeline-ready");
        } catch (error) {
            const msg = error.message || error.reason || error.stack || "Unknown error";
            Logger.error(`Failed to run pipeline: ${msg}`);
        }
    }
}