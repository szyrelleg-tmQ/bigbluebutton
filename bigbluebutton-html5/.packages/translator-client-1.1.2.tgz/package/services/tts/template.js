export class TTSProvider {
    constructor() { }
    async initialize() { }
    async speak(text) { }
    setLanguage(language) { }
    setVoice(voice) { }
    getLanguages() { }
    getVoices() { }
    onLanguageChange(callback) { }
    onVoiceChange(callback) { }
    destroy() { }
}