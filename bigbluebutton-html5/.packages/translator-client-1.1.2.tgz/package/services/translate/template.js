export class TranslateProvider {
    constructor() { }
    async initialize() { }
    async destroy() { }
    async translateText({ text, source = 'en', target = 'fr' }) { }
    getLanguages() { }
    getLanguageByCode(code) { }
    getSupportedLanguageCodes() { }
    isLanguageSupported(code) { }
}