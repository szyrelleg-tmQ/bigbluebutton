import { TranslateProvider } from "./template.js";

export class GoogleWebTranslateProvider extends TranslateProvider {
    #baseUrl = "https://translate.googleapis.com/translate_a/single?client=gtx&sl={{source}}&tl={{target}}&dt=t&q={{text}}";

    // Comprehensive language list for Google Translate
    #languages = {
        "Auto-detect": "auto",
        "Afrikaans": "af",
        "Albanian": "sq",
        "Amharic": "am",
        "Arabic": "ar",
        "Armenian": "hy",
        "Azerbaijani": "az",
        "Basque": "eu",
        "Belarusian": "be",
        "Bengali": "bn",
        "Bosnian": "bs",
        "Bulgarian": "bg",
        "Catalan": "ca",
        "Cebuano": "ceb",
        "Chinese (Simplified)": "zh-cn",
        "Chinese (Traditional)": "zh-tw",
        "Corsican": "co",
        "Croatian": "hr",
        "Czech": "cs",
        "Danish": "da",
        "Dutch": "nl",
        "English": "en",
        "Esperanto": "eo",
        "Estonian": "et",
        "Finnish": "fi",
        "French": "fr",
        "Frisian": "fy",
        "Galician": "gl",
        "Georgian": "ka",
        "German": "de",
        "Greek": "el",
        "Gujarati": "gu",
        "Haitian Creole": "ht",
        "Hausa": "ha",
        "Hawaiian": "haw",
        "Hebrew": "he",
        "Hindi": "hi",
        "Hmong": "hmn",
        "Hungarian": "hu",
        "Icelandic": "is",
        "Igbo": "ig",
        "Indonesian": "id",
        "Irish": "ga",
        "Italian": "it",
        "Japanese": "ja",
        "Javanese": "jw",
        "Kannada": "kn",
        "Kazakh": "kk",
        "Khmer": "km",
        "Korean": "ko",
        "Kurdish": "ku",
        "Kyrgyz": "ky",
        "Lao": "lo",
        "Latin": "la",
        "Latvian": "lv",
        "Lithuanian": "lt",
        "Luxembourgish": "lb",
        "Macedonian": "mk",
        "Malagasy": "mg",
        "Malay": "ms",
        "Malayalam": "ml",
        "Maltese": "mt",
        "Maori": "mi",
        "Marathi": "mr",
        "Mongolian": "mn",
        "Myanmar": "my",
        "Nepali": "ne",
        "Norwegian": "no",
        "Pashto": "ps",
        "Persian": "fa",
        "Polish": "pl",
        "Portuguese": "pt",
        "Punjabi": "pa",
        "Romanian": "ro",
        "Russian": "ru",
        "Samoan": "sm",
        "Scottish Gaelic": "gd",
        "Serbian": "sr",
        "Sesotho": "st",
        "Shona": "sn",
        "Sindhi": "sd",
        "Sinhala": "si",
        "Slovak": "sk",
        "Slovenian": "sl",
        "Somali": "so",
        "Spanish": "es",
        "Sundanese": "su",
        "Swahili": "sw",
        "Swedish": "sv",
        "Tagalog": "tl",
        "Tajik": "tg",
        "Tamil": "ta",
        "Telugu": "te",
        "Thai": "th",
        "Turkish": "tr",
        "Ukrainian": "uk",
        "Urdu": "ur",
        "Uzbek": "uz",
        "Vietnamese": "vi",
        "Welsh": "cy",
        "Xhosa": "xh",
        "Yiddish": "yi",
        "Yoruba": "yo",
        "Zulu": "zu"
    };

    constructor() {
        super();
    }

    async translateText({ text, source = 'en', target = 'fr' }) {
        if (!text) return;
        const url = this.#baseUrl.replace("{{source}}", source).replace("{{target}}", target).replace("{{text}}", encodeURIComponent(text));
        const response = await fetch(url);
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = await response.json();
        const translated = data[0].map(segment => segment[0]).join('');
        return translated;
    }

    /**
     * Get all supported languages
     * @returns {Object} Object with language names as keys and language codes as values
     */
    getLanguages() {
        return { ...this.#languages };
    }

    /**
     * Get language name by language code
     * @param {string} code - Language code (e.g., 'en', 'es', 'fr')
     * @returns {string|null} Language name or null if not found
     */
    getLanguageByCode(code) {
        const entry = Object.entries(this.#languages).find(([name, langCode]) => langCode === code);
        return entry ? entry[0] : null;
    }

    /**
     * Get supported language codes
     * @returns {string[]} Array of supported language codes
     */
    getSupportedLanguageCodes() {
        return Object.values(this.#languages);
    }

    /**
     * Check if a language code is supported
     * @param {string} code - Language code to check
     * @returns {boolean} True if supported, false otherwise
     */
    isLanguageSupported(code) {
        return Object.values(this.#languages).includes(code);
    }

    /**
     * Get languages suitable for source selection (includes auto-detect)
     * @returns {Object} Object with language names as keys and language codes as values
     */
    getSourceLanguages() {
        return { ...this.#languages };
    }

    /**
     * Get languages suitable for target selection (excludes auto-detect)
     * @returns {Object} Object with language names as keys and language codes as values
     */
    getTargetLanguages() {
        const targetLanguages = { ...this.#languages };
        delete targetLanguages["Auto-detect"];
        return targetLanguages;
    }
}