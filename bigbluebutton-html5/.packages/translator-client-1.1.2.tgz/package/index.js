import { RTVIClient, RTVIEvent } from '@pipecat-ai/client-js';
import { DailyTransport } from '@pipecat-ai/daily-transport';
import { getDailyManager, resetDailyManager, createDailyManager } from './DailyManager.js';

let instance = null;
let instanceConfig = null;

// --- Bot/Transcription logic migrated from services/daily.ts ---
let rtviClient = null;
let transcriptionCallback = null;
const userTranscriptQueue = [];
const botTranscriptQueue = [];

function getRtviClient(baseUrl = 'http://localhost:7860/') {
    if (typeof window === 'undefined') {
        return null;
    }
    if (!rtviClient) {
        const transport = new DailyTransport();
        rtviClient = new RTVIClient({
            transport: transport,
            params: {
                baseUrl: baseUrl,
                endpoints: {
                    connect: '/start-bot',
                }
            },
            enableMic: true,
            enableCam: false,
            timeout: 15 * 1000,
            callbacks: {
                onBotConnected: () => {
                    console.log('[CALLBACK] Bot connected');
                },
                onUserTranscript(data) {
                    if (data.final && data.text) {
                        userTranscriptQueue.push(data.text);
                        // Try to pair
                        if (userTranscriptQueue.length > 0 && botTranscriptQueue.length > 0) {
                            const user = userTranscriptQueue.shift();
                            const bot = botTranscriptQueue.shift();
                            if (transcriptionCallback) {
                                transcriptionCallback(user, bot);
                            }
                        }
                    }
                },
                onBotTranscript(data) {
                    if (data.text) {
                        botTranscriptQueue.push(data.text);
                        // Try to pair
                        if (userTranscriptQueue.length > 0 && botTranscriptQueue.length > 0) {
                            const user = userTranscriptQueue.shift();
                            const bot = botTranscriptQueue.shift();
                            if (transcriptionCallback) {
                                transcriptionCallback(user, bot);
                            }
                        }
                    }
                },
                onBotDisconnected: () => {
                    console.log('[CALLBACK] Bot disconnected');
                },
                onBotReady: () => {
                    console.log('[CALLBACK] Bot ready to chat!');
                },
            },
        });
        // Events
        rtviClient.on(RTVIEvent.Connected, () => {
            console.log('[EVENT] User connected');
        });
        rtviClient.on(RTVIEvent.Disconnected, () => {
            console.log('[EVENT] User disconnected');
        });
    }
    return rtviClient;
}

function setTranscriptionCallback(callback) {
    transcriptionCallback = callback;
}

async function setLanguages(from, to, baseUrl = 'http://localhost:7860/') {
    await getRtviClient(baseUrl)?.action({
        service: 'languages', action: 'set_lang', arguments: [{
            name: 'languages', value: { to, from }
        }]
    });
}

// --- startBot logic migrated from app/actions.ts ---
async function startBot(roomName, userName = 'Anonymous', language = 'Spanish', baseUrl = 'http://localhost:7860/', voice = 'aria', is_video_off = false) {
    // Use browser-safe UUID
    const sessionId = (typeof crypto !== 'undefined' && crypto.randomUUID) ? crypto.randomUUID() : Math.random().toString(36).substring(2, 15);

    // Build the URL with query parameters
    // const url = new URL(baseUrl);
    // url.searchParams.set('language', language);
    // url.searchParams.set('session_id', `${userName}-${sessionId}`);
    // url.searchParams.set('room_name', roomName);

    // Fetch and expect a JSON response
    // const res = await fetch(url.toString(), {
    //     method: 'GET',
    //     headers: { 'Content-Type': 'application/json' },
    // });
    const res = await fetch(`${baseUrl}/room`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            room_name: roomName,
            is_video_off,
            language: language,
            userName: `${userName}-${sessionId}`,
            voice: voice
        }),
    });

    if (!res.ok) throw new Error(await res.text());
    const data = await res.json();
    return data;
}
// --- End migrated logic ---

class TranslatorClient {
    constructor(config = {}) {
        // Use createDailyManager for non-singleton instances, getDailyManager for singleton
        this.daily = config.isMultiInstance ? createDailyManager(config.inputConfig) : getDailyManager(config.inputConfig);
        this.token = null;
        this.config = config;
        this.baseUrl = config.baseUrl || 'http://localhost:7860/';
        this.isMultiInstance = config.isMultiInstance || false;

        // Set up P2P message handling
        this.setupP2PHandling();
    }

    // Setup P2P message handling
    setupP2PHandling() {
        this.daily.on('p2p-message', (event) => {
            this.handleP2PMessage(event.message, event.senderId);
        });
    }

    // Bot/room creation
    async startBot(userName, language = "english", roomId = '', voice = 'aria', is_video_off = false) {
        return await startBot(roomId, userName, language, this.baseUrl, voice, is_video_off);
    }

    // Set token for room joining
    setToken(token) {
        this.token = token;
    }

    // Daily room join/leave
    async joinRoom(roomUrl, userName, options = {}) {
        // Reinitialize if destroyed
        this.reinitialize();

        const joinOptions = {
            userName,
            ...options
        };

        // Add token if available
        if (this.token) {
            joinOptions.token = this.token;
        }

        return await this.daily.joinRoom(roomUrl, joinOptions);
    }

    async leaveRoom() {
        this.reinitialize();
        return await this.daily.leaveRoom();
    }

    // Audio/video controls
    toggleAudio() {
        this.reinitialize();
        return this.daily.toggleAudio();
    }

    toggleVideo() {
        this.reinitialize();
        return this.daily.toggleVideo();
    }

    // Participants
    getParticipants() {
        this.reinitialize();
        const state = this.daily.getCallState();
        return state ? state.participants : [];
    }

    // Get the Daily call object directly
    getCallObject() {
        this.reinitialize();
        return this.daily.getCallObject();
    }

    // Get the Daily call object directly (alias for consistency)
    get CallObject() {
        this.reinitialize();
        return this.daily.getCallObject();
    }

    // Transcription
    setTranscriptionCallback(cb) {
        setTranscriptionCallback(cb);
    }

    // Language
    setLanguage(lang) {
        this.reinitialize();
        if (this.daily && this.daily.call) {
            // Get local participant's session_id
            const participants = this.daily.call.participants();
            const localParticipantId = participants?.local?.session_id;
            this.daily.call.sendAppMessage({
                event_type: 'update_language',
                participant_id: localParticipantId,
                language: lang,
            }, '*');
        }
    }

    // P2P Language/Voice Change Requests
    requestRemoteLanguageChange(targetParticipantId, language) {
        this.reinitialize();
        if (this.daily && this.daily.call) {
            this.daily.call.sendAppMessage({
                event_type: 'p2p_language_change_request',
                target_participant_id: targetParticipantId,
                language: language,
                timestamp: Date.now()
            }, targetParticipantId); // Send only to target participant
        }
    }

    requestRemoteVoiceChange(targetParticipantId, voiceKey, targetLanguage) {
        this.reinitialize();
        if (this.daily && this.daily.call) {
            this.daily.call.sendAppMessage({
                event_type: 'p2p_voice_change_request',
                target_participant_id: targetParticipantId,
                voice_key: voiceKey,
                language: targetLanguage,
                timestamp: Date.now()
            }, targetParticipantId); // Send only to target participant
        }
    }

    // Handle incoming P2P requests
    handleP2PMessage(message, senderId) {
        console.log('🎧 P2P message received:', {
            type: message.event_type,
            from: senderId,
            message: message
        });

        switch (message.event_type) {
            case 'p2p_language_change_request':
                // Remote user is requesting this participant to change their language
                console.log('🎧 Processing P2P language change request:', message.language);
                // Update our own language (which will update our bot that the requester sees as "remote")
                this.setLanguage(message.language);
                console.log('🎧 Language change request processed');
                break;

            case 'p2p_voice_change_request':
                // Remote user is requesting this participant to change their voice
                console.log('🎧 Processing P2P voice change request:', message.voice_key, message.language);
                // Update our own voice (which will update our bot that the requester sees as "remote")
                this.setVoice(message.voice_key, message.language);
                console.log('🎧 Voice change request processed');
                break;

            default:
                console.log('🎧 Unknown P2P message type:', message.event_type);
                break;
        }
    }

    // detect_language
    detectLanguage() {
        this.reinitialize();
        if (this.daily && this.daily.call) {
            this.daily.call.sendAppMessage({
                event_type: 'detect_language',
            }, '*');
        }
    }

    setVoice(voiceKey, targetLanguage) {
        this.reinitialize();
        if (this.daily && this.daily.call) {
            this.daily.call.sendAppMessage({
                event_type: 'update_voice',
                voice_key: voiceKey,
                language: targetLanguage,
            }, '*');
        }
    }

    // Event handling
    on(event, handler) {
        this.reinitialize();
        this.daily.on(event, handler);
    }

    off(event, handler) {
        this.reinitialize();
        this.daily.off(event, handler);
    }

    // Cleanup
    destroy() {
        if (this.daily) {
            this.daily.destroy();
            this.daily = null;
        }
        setTranscriptionCallback(null);
        this.token = null;

        // Only reset singleton instances if this is a singleton client
        if (!this.isMultiInstance) {
            // Reset singleton instances to allow recreation
            instance = null;
            instanceConfig = null;

            // Reset daily manager
            resetDailyManager();
        }
    }

    // Method to reinitialize if destroyed
    reinitialize() {
        if (!this.daily || !this.daily.isInitialized) {
            this.daily = getDailyManager();
        }
    }

    // Check if client is initialized
    isInitialized() {
        return this.daily && this.daily.isInitialized;
    }

    // Fetch available voices
    async fetchVoices() {
        try {
            const response = await fetch(`${this.baseUrl}/api/voices`);

            if (!response.ok) {
                throw new Error(`Failed to fetch voices: ${response.status}`);
            }

            const data = await response.json();

            // Add icons to voice data
            const voicesWithIcons = data.voices.map((voice) => ({
                ...voice,
            }));

            return voicesWithIcons;
        } catch (err) {
            console.error('Error fetching voices:', err);

            // Fallback to default voices if API fails
            const fallbackVoices = [
                {
                    key: 'aria',
                    name: 'Aria',
                    description: 'Clear and professional',
                },
                {
                    key: 'nova',
                    name: 'Nova',
                    description: 'Warm and friendly',
                },
                {
                    key: 'sage',
                    name: 'Sage',
                    description: 'Calm and soothing',
                }
            ];

            return fallbackVoices;
        }
    }

    // Fetch available languages
    async fetchLanguages() {
        const response = await fetch(`${this.baseUrl}/api/languages`);
        const data = await response.json();
        return data.languages;
    }

    async fetchRemoteSettings() {
        const response = await fetch(`${this.baseUrl}/api/remote-settings`);
        const data = await response.json();
        return data.settings;
    }
}

// Add a method to reset the singleton cache
export function resetTranslatorClient() {
    instance = null;
    instanceConfig = null;
}

// NEW: Non-singleton function for creating multiple instances
export function createTranslatorClient(config = {}) {
    if (typeof window === 'undefined') {
        return null;
    }
    // Always create a new instance, bypassing singleton pattern
    return new TranslatorClient({ ...config, isMultiInstance: true });
}

// Keep existing singleton function for main UI
export function getTranslatorClient(config = {}) {
    if (typeof window === 'undefined') {
        return null;
    }
    if (!instance || JSON.stringify(instanceConfig) !== JSON.stringify(config)) {
        instance = new TranslatorClient(config);
        instanceConfig = config;
    }
    return instance;
}

// Export modules from /modules directory
export { default as AudioRoutingService, getAudioRoutingService, resetAudioRoutingService } from './modules/AudioRoutingService.js';
export { default as DeviceDetection } from './modules/DeviceDetection.js';
export { default as AudioDeviceSelector, getAudioDeviceSelector, resetAudioDeviceSelector, selectVirtualCableDevices } from './modules/AudioDeviceSelector.js';
export { ClientProviders } from './services/index.js';