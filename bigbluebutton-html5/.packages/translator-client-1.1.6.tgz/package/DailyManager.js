import Daily from '@daily-co/daily-js';

class AudioMixer {
    constructor(mixerId, audioElementId) {
        this.mixerId = mixerId;
        this.audioElementId = audioElementId;
        this.audioContext = null;
        this.mixedAudioDestination = null;
        this.mixedAudioElement = null;
        this.participantSources = new Map(); // Track audio sources per participant
        this.isInitialized = false;
    }

    async initializeAudioMixer() {
        if (this.isInitialized) return;

        try {
            // Create AudioContext
            this.audioContext = new (window.AudioContext || window.webkitAudioContext)();

            // Create destination for mixed audio
            this.mixedAudioDestination = this.audioContext.createMediaStreamDestination();

            // Create the single audio element for this mixer type
            this.mixedAudioElement = document.createElement('audio');
            this.mixedAudioElement.id = this.audioElementId;
            this.mixedAudioElement.className = `mixed-audio ${this.mixerId}`;
            this.mixedAudioElement.autoplay = true;
            this.mixedAudioElement.playsInline = true;
            this.mixedAudioElement.srcObject = this.mixedAudioDestination.stream;

            // Add to DOM
            document.body.appendChild(this.mixedAudioElement);

            this.isInitialized = true;
            console.log(`Audio mixer initialized successfully for ${this.mixerId}`);
        } catch (error) {
            console.error(`Failed to initialize audio mixer for ${this.mixerId}:`, error);
        }
    }

    async addParticipantAudio(participantId, audioStream) {
        if (!this.isInitialized) {
            await this.initializeAudioMixer();
        }

        try {
            // Remove existing source if it exists
            if (this.participantSources.has(participantId)) {
                this.removeParticipantAudio(participantId);
            }

            // Create audio source from the stream
            const source = this.audioContext.createMediaStreamSource(audioStream);

            // Connect to the mixed destination
            source.connect(this.mixedAudioDestination);

            // Store the source for later cleanup
            this.participantSources.set(participantId, source);

            console.log(`Added audio for participant ${participantId} to ${this.mixerId} mixer`);
        } catch (error) {
            console.error(`Failed to add audio for participant ${participantId} to ${this.mixerId}:`, error);
        }
    }

    removeParticipantAudio(participantId) {
        const source = this.participantSources.get(participantId);
        if (source) {
            try {
                source.disconnect();
                this.participantSources.delete(participantId);
                console.log(`Removed audio for participant ${participantId} from ${this.mixerId} mixer`);
            } catch (error) {
                console.error(`Failed to remove audio for participant ${participantId} from ${this.mixerId}:`, error);
            }
        }
    }

    setVolume(volume) {
        if (this.mixedAudioElement) {
            this.mixedAudioElement.volume = Math.max(0, Math.min(1, volume));
        }
    }

    mute() {
        if (this.mixedAudioElement) {
            this.mixedAudioElement.muted = true;
        }
    }

    unmute() {
        if (this.mixedAudioElement) {
            this.mixedAudioElement.muted = false;
        }
    }

    getParticipantCount() {
        return this.participantSources.size;
    }

    cleanup() {
        // Disconnect all sources
        this.participantSources.forEach((source, participantId) => {
            this.removeParticipantAudio(participantId);
        });

        // Remove audio element
        if (this.mixedAudioElement && this.mixedAudioElement.parentNode) {
            this.mixedAudioElement.parentNode.removeChild(this.mixedAudioElement);
        }

        // Close audio context
        if (this.audioContext && this.audioContext.state !== 'closed') {
            this.audioContext.close();
        }

        this.isInitialized = false;
    }
}

class DailyManager {
    constructor() {
        this.call = null;
        this.isInitialized = false;
        this.currentRoomUrl = null;
        this.participants = new Map();
        this.eventHandlers = new Map();

        // Create 3 separate audio mixers
        this.audioMixers = {
            'bot-local': new AudioMixer('bot-local', 'mixed-bot-local-audio'),
            'bot-remote': new AudioMixer('bot-remote', 'mixed-bot-remote-audio'),
            'remote': new AudioMixer('remote', 'mixed-remote-audio')
        };

        this.init();
    }

    init() {
        this.call = Daily.createCallObject();
        this.setupEventListeners();
        this.isInitialized = true;
    }

    setupEventListeners() {
        if (!this.call) return;

        this.call.on('joined-meeting', this.handleJoinedMeeting.bind(this));
        this.call.on('left-meeting', this.handleLeftMeeting.bind(this));
        this.call.on('participant-joined', this.handleParticipantJoined.bind(this));
        this.call.on('participant-left', this.handleParticipantLeft.bind(this));
        this.call.on('participant-updated', this.handleParticipantUpdated.bind(this));
        this.call.on('active-speaker-change', this.handleActiveSpeakerChange.bind(this));
        this.call.on('error', this.handleError.bind(this));
        this.call.on("app-message", this.handleAppMessage.bind(this));
    }

    async joinRoom(roomUrl, options = {}) {
        try {
            if (!this.isInitialized) {
                this.init();
            }

            this.currentRoomUrl = roomUrl;
            const joinOptions = { url: roomUrl, ...options };
            const res = await this.call.join(joinOptions);
            this.emitEvent('room-joined', { roomUrl });
            return true;
        } catch (error) {
            console.error('DailyManager: Error joining room:', error);
            this.emitEvent('room-error', { error: error.message });
            return false;
        }
    }

    async leaveRoom() {
        try {
            if (!this.call) return true;

            // Clean up all audio mixers before leaving
            Object.values(this.audioMixers).forEach(mixer => mixer.cleanup());

            await this.call.leave();
            this.participants.clear();
            this.currentRoomUrl = null;
            this.emitEvent('room-left', {});
            return true;
        } catch (error) {
            console.error('DailyManager: Error leaving room:', error);
            return false;
        }
    }

    determineParticipantType(participant) {
        const currentUserName = typeof window !== 'undefined' && window.location ?
            new URLSearchParams(window.location.search).get('participantName') : null;
        const isCurrentUser = participant.local || (currentUserName && participant.user_name === currentUserName);

        if (isCurrentUser) {
            return 'local';
        } else if (participant.user_name && participant.user_name.startsWith('bot-')) {
            const botGuestPart = participant.user_name.replace('bot-', '');
            return (currentUserName && botGuestPart === currentUserName) ? 'bot-local' : 'bot-remote';
        } else {
            return 'remote';
        }
    }

    async handleParticipantAudio(participantId, participant) {
        try {
            const participantType = this.determineParticipantType(participant);

            // Remove from all mixers first (in case participant type changed)
            Object.values(this.audioMixers).forEach(mixer => {
                mixer.removeParticipantAudio(participantId);
            });

            // Only handle audio for non-local participants
            if (participantType !== 'local' && this.audioMixers[participantType]) {
                const audioTrack = participant.tracks?.audio?.persistentTrack;

                if (audioTrack && audioTrack.readyState === 'live') {
                    // Create MediaStream with the audio track
                    const audioStream = new MediaStream([audioTrack]);

                    // Add to appropriate mixer
                    await this.audioMixers[participantType].addParticipantAudio(participantId, audioStream);
                }
            }
        } catch (error) {
            console.error(`Failed to handle audio for participant ${participantId}:`, error);
        }
    }

    handleJoinedMeeting(event) {
        this.emitEvent('joined-meeting', event);
    }

    handleLeftMeeting(event) {
        // Clean up all audio mixers
        Object.values(this.audioMixers).forEach(mixer => mixer.cleanup());
        this.participants.clear();
        this.emitEvent('left-meeting', event);
    }

    async handleParticipantJoined(event) {
        const { participant } = event;
        const participantId = participant.session_id;

        this.participants.set(participantId, participant);

        // Handle audio for the new participant
        await this.handleParticipantAudio(participantId, participant);

        this.emitEvent('participant-joined', { participant });
    }

    handleParticipantLeft(event) {
        const { participant } = event;
        const participantId = participant.session_id;

        this.participants.delete(participantId);

        // Remove participant from all audio mixers
        Object.values(this.audioMixers).forEach(mixer => {
            mixer.removeParticipantAudio(participantId);
        });

        this.emitEvent('participant-left', { participant });
    }

    async handleParticipantUpdated(event) {
        const { participant } = event;
        const participantId = participant.session_id;

        this.participants.set(participantId, participant);

        // Update audio handling when participant tracks change
        await this.handleParticipantAudio(participantId, participant);

        this.emitEvent('participant-updated', { participant });
    }

    handleAppMessage(event) {
        // Check if this is a P2P language/voice change request
        const { data, fromId } = event;

        if (data && (data.event_type === 'p2p_language_change_request' ||
            data.event_type === 'p2p_voice_change_request')) {
            // This is a P2P request, emit special event for handling
            this.emitEvent('p2p-message', { message: data, senderId: fromId });
        }

        // Emit regular app-message event for other handlers
        this.emitEvent('app-message', event);
    }

    handleActiveSpeakerChange(event) {
        this.emitEvent('active-speaker-change', event);
    }

    handleError(event) {
        console.error('DailyManager: Error:', event);
        this.emitEvent('error', event);
    }

    toggleVideo() {
        if (!this.call) return false;
        const newState = !this.call.localVideo();
        this.call.setLocalVideo(newState);
        return newState;
    }

    toggleAudio() {
        if (!this.call) return false;
        const newState = !this.call.localAudio();
        this.call.setLocalAudio(newState);
        return newState;
    }

    // Audio mixer control methods for each type
    muteBotLocalAudio() {
        this.audioMixers['bot-local'].mute();
    }

    unmuteBotLocalAudio() {
        this.audioMixers['bot-local'].unmute();
    }

    setBotLocalAudioVolume(volume) {
        this.audioMixers['bot-local'].setVolume(volume);
    }

    muteBotRemoteAudio() {
        this.audioMixers['bot-remote'].mute();
    }

    unmuteBotRemoteAudio() {
        this.audioMixers['bot-remote'].unmute();
    }

    setBotRemoteAudioVolume(volume) {
        this.audioMixers['bot-remote'].setVolume(volume);
    }

    muteRemoteAudio() {
        this.audioMixers['remote'].mute();
    }

    unmuteRemoteAudio() {
        this.audioMixers['remote'].unmute();
    }

    setRemoteAudioVolume(volume) {
        this.audioMixers['remote'].setVolume(volume);
    }

    // Convenience methods to control all types
    muteAllAudio() {
        Object.values(this.audioMixers).forEach(mixer => mixer.mute());
    }

    unmuteAllAudio() {
        Object.values(this.audioMixers).forEach(mixer => mixer.unmute());
    }

    setAllAudioVolume(volume) {
        Object.values(this.audioMixers).forEach(mixer => mixer.setVolume(volume));
    }

    // Get statistics about each mixer
    getAudioStats() {
        return {
            'bot-local': this.audioMixers['bot-local'].getParticipantCount(),
            'bot-remote': this.audioMixers['bot-remote'].getParticipantCount(),
            'remote': this.audioMixers['remote'].getParticipantCount()
        };
    }

    getCallState() {
        if (!this.call) return null;

        return {
            isJoined: this.call.meetingState() === 'joined-meeting',
            roomUrl: this.currentRoomUrl,
            participants: Array.from(this.participants.values()),
            localVideo: this.call.localVideo(),
            localAudio: this.call.localAudio(),
            meetingState: this.call.meetingState(),
            audioStats: this.getAudioStats()
        };
    }

    getCallObject() {
        return this.call;
    }

    on(eventName, handler) {
        if (!this.eventHandlers.has(eventName)) {
            this.eventHandlers.set(eventName, []);
        }
        this.eventHandlers.get(eventName).push(handler);
    }

    off(eventName, handler) {
        if (!this.eventHandlers.has(eventName)) return;

        const handlers = this.eventHandlers.get(eventName);
        const index = handlers.indexOf(handler);
        if (index > -1) {
            handlers.splice(index, 1);
        }
    }

    emitEvent(eventName, data) {
        if (!this.eventHandlers.has(eventName)) return;

        this.eventHandlers.get(eventName).forEach(handler => {
            try {
                handler(data);
            } catch (error) {
                console.error(`DailyManager: Error in event handler for ${eventName}:`, error);
            }
        });
    }

    destroy() {
        // Clean up all audio mixers first
        Object.values(this.audioMixers).forEach(mixer => mixer.cleanup());

        if (this.call) {
            this.call.destroy();
            this.call = null;
        }

        this.participants.clear();
        this.eventHandlers.clear();
        this.isInitialized = false;
        this.currentRoomUrl = null;

        // Reset singleton instance to allow recreation
        instance = null;
    }

    // Method to reinitialize if destroyed
    reinitialize() {
        if (!this.isInitialized) {
            this.init();
        }
    }
}

// Add a method to reset the singleton cache
export function resetDailyManager() {
    instance = null;
}

// NEW: Non-singleton function for creating multiple instances
export function createDailyManager() {
    if (typeof window === 'undefined') {
        return null;
    }
    // Always create a new instance, bypassing singleton pattern
    return new DailyManager();
}

// Keep existing singleton function for main UI
let instance = null;
export function getDailyManager() {
    if (typeof window === 'undefined') {
        return null;
    }
    if (!instance) {
        instance = new DailyManager();
    }
    return instance;
}