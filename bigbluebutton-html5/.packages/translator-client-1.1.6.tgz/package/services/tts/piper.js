import { TTSProvider } from "./template";
import { TTSManager } from "@tmq.paul/client-tts";

export class PiperTTSProvider extends TTSProvider {
    #instance = null;
    #language = "en";
    #voice = null;
    constructor() {
        super();
    }
    /**
     * @returns {TTSManager}
     */
    get Instance() { return this.#instance; }
    async initialize() {
        this.#instance = new TTSManager({ provider: "piper" });
        return this.Instance.initialize();
    }
    speak(text) {
        if (this.Instance) {
            this.Instance.speak(text);
        }
    }
    setLanguage(language) {
        this.#language = language;
        return this.Instance.setLanguage(language);
    }
    setVoice(voice) {
        this.#voice = voice;
        return this.Instance.setVoiceByKey(voice);
    }
    destroy() {
        if (this.Instance) {
            this.Instance.destroy();
        }
    }
    getLanguages() {
        return {
            ENGLISH: "en",
            SPANISH: "es",
            FRENCH: "fr",
            GERMAN: "de",
            ITALIAN: "it",
            PORTUGUESE: "pt",
            RUSSIAN: "ru",
        };
    }
    getVoices() {
        if (this.Instance) {
            return this.Instance.getVoicesForLanguage(this.#language);
        }
        return [];
    }
}