import Daily from '@daily-co/daily-js';

class DailyManager {
    constructor(config = {}) {
        this.call = null;
        this.isInitialized = false;
        this.currentRoomUrl = null;
        this.participants = new Map();
        this.eventHandlers = new Map();
        this.participantAudio = {};
        this.init(config);
    }

    init(config) {
        this.call = Daily.createCallObject(config);
        this.setupEventListeners();
        this.isInitialized = true;
    }

    setupEventListeners() {
        if (!this.call) return;

        this.call.on('joined-meeting', this.handleJoinedMeeting.bind(this));
        this.call.on('left-meeting', this.handleLeftMeeting.bind(this));
        this.call.on('participant-joined', this.handleParticipantJoined.bind(this));
        this.call.on('participant-left', this.handleParticipantLeft.bind(this));
        this.call.on('participant-updated', this.handleParticipantUpdated.bind(this));
        this.call.on('active-speaker-change', this.handleActiveSpeakerChange.bind(this));
        this.call.on('error', this.handleError.bind(this));
        this.call.on("app-message", this.handleAppMessage.bind(this));
    }

    async joinRoom(roomUrl, options = {}) {
        try {
            if (!this.isInitialized) {
                this.init();
            }

            this.currentRoomUrl = roomUrl;
            const joinOptions = { url: roomUrl, ...options };
            const res = await this.call.join(joinOptions);
            if (res) this.call.setLocalAudio(false);
            this.emitEvent('room-joined', { roomUrl });
            return true;
        } catch (error) {
            console.error('DailyManager: Error joining room:', error);
            this.emitEvent('room-error', { error: error.message });
            return false;
        }
    }

    async leaveRoom() {
        try {
            if (!this.call) return true;
            await this.call.leave();
            this.participants.clear();
            this.currentRoomUrl = null;
            this.emitEvent('room-left', {});
            return true;
        } catch (error) {
            console.error('DailyManager: Error leaving room:', error);
            return false;
        }
    }

    createVideoFrame(participantId, participant) {
        const existingFrame = document.getElementById(`video-frame-${participantId}`);
        if (existingFrame) {
            existingFrame.remove();
        }

        const videoContainer = document.createElement('div');
        videoContainer.id = `video-frame-${participantId}`;
        videoContainer.className = 'video-frame';
        videoContainer.setAttribute('data-participant-id', participantId);

        const videoElement = document.createElement('video');
        videoElement.className = 'video-element';
        videoElement.autoplay = true;
        videoElement.playsInline = true;
        videoElement.muted = participant.local || false;

        const currentUserName = typeof window !== 'undefined' && window.location ?
            new URLSearchParams(window.location.search).get('participantName') : null;
        const isCurrentUser = participant.local || (currentUserName && participant.user_name === currentUserName);

        let participantType;
        if (isCurrentUser) {
            participantType = 'local';
        } else if (participant.user_name && participant.user_name.startsWith('bot-')) {
            const botGuestPart = participant.user_name.replace('bot-', '');
            participantType = (currentUserName && botGuestPart === currentUserName) ? 'bot-local' : 'bot-remote';
        } else {
            participantType = 'remote';
        }

        videoElement.setAttribute('data-participant-id', participantId);
        videoElement.setAttribute('data-participant-type', participantType);

        if (participantType !== 'local') {
            const audioElement = document.createElement('audio');
            audioElement.id = `audio-${participantId}`;
            audioElement.autoplay = true;
            audioElement.playsInline = true;
            audioElement.setAttribute('data-participant-id', participantId);
            audioElement.setAttribute('data-participant-type', participantType);
            videoContainer.appendChild(audioElement);

            // Store a reference to the audio element
            this.participantAudio[participantId] = audioElement;
        }

        videoContainer.appendChild(videoElement);
        return videoContainer;
    }

    setParticipantVolume(participantId, volume) {
        const audioElement = this.participantAudio[participantId];
        if (audioElement) {
            // Clamp the volume to be between 0.0 and 1.0
            audioElement.volume = Math.max(0, Math.min(1, volume));
        } else {
            console.warn(`Audio element not found for participant: ${participantId}`);
        }
    }

    updateVideoFrame(participantId, tracks) {
        const videoContainer = document.getElementById(`video-frame-${participantId}`);
        if (!videoContainer) return;

        const videoElement = videoContainer.querySelector('.video-element');
        const audioElement = videoContainer.querySelector(`#audio-${participantId}`);

        if (tracks.video && tracks.video.persistentTrack) {
            videoElement.srcObject = new MediaStream([tracks.video.persistentTrack]);
            videoElement.style.display = tracks.video.state === 'playable' ? 'block' : 'none';
        }

        if (tracks.audio && audioElement && tracks.audio.persistentTrack) {
            audioElement.srcObject = new MediaStream([tracks.audio.persistentTrack]);
        }
    }

    removeVideoFrame(participantId) {
        const videoContainer = document.getElementById(`video-frame-${participantId}`);
        if (videoContainer) {
            const videoElement = videoContainer.querySelector('.video-element');
            const audioElement = videoContainer.querySelector(`#audio-${participantId}`);

            if (videoElement) videoElement.srcObject = null;
            if (audioElement) audioElement.srcObject = null;

            videoContainer.remove();
        }
    }

    handleJoinedMeeting(event) {
        this.emitEvent('joined-meeting', event);
    }

    handleLeftMeeting(event) {
        this.participants.forEach((participant, participantId) => {
            this.removeVideoFrame(participantId);
        });
        this.participants.clear();
        this.emitEvent('left-meeting', event);
    }

    handleParticipantJoined(event) {
        const { participant } = event;
        const participantId = participant.session_id;

        this.participants.set(participantId, participant);

        const videoFrame = this.createVideoFrame(participantId, participant);
        const videoContainer = document.getElementById('video-container') || document.body;
        videoContainer.appendChild(videoFrame);

        this.emitEvent('participant-joined', { participant, videoFrame });
    }

    handleParticipantLeft(event) {
        const { participant } = event;
        const participantId = participant.session_id;

        this.participants.delete(participantId);
        this.removeVideoFrame(participantId);

        this.emitEvent('participant-left', { participant });
    }

    handleParticipantUpdated(event) {
        const { participant } = event;
        const participantId = participant.session_id;

        this.participants.set(participantId, participant);
        this.updateVideoFrame(participantId, participant.tracks);

        this.emitEvent('participant-updated', { participant });
    }

    handleAppMessage(event) {
        // Check if this is a P2P language/voice change request
        const { data, fromId } = event;

        if (data && (data.event_type === 'p2p_language_change_request' ||
            data.event_type === 'p2p_voice_change_request')) {
            // This is a P2P request, emit special event for handling
            this.emitEvent('p2p-message', { message: data, senderId: fromId });
        }

        // Emit regular app-message event for other handlers
        this.emitEvent('app-message', event);
    }

    handleActiveSpeakerChange(event) {
        this.emitEvent('active-speaker-change', event);
    }

    handleError(event) {
        console.error('DailyManager: Error:', event);
        this.emitEvent('error', event);
    }

    toggleVideo() {
        if (!this.call) return false;
        const newState = !this.call.localVideo();
        this.call.setLocalVideo(newState);
        return newState;
    }

    toggleAudio() {
        if (!this.call) return false;
        const newState = !this.call.localAudio();
        this.call.setLocalAudio(newState);
        return newState;
    }

    getCallState() {
        if (!this.call) return null;

        return {
            isJoined: this.call.meetingState() === 'joined-meeting',
            roomUrl: this.currentRoomUrl,
            participants: Array.from(this.participants.values()),
            localVideo: this.call.localVideo(),
            localAudio: this.call.localAudio(),
            meetingState: this.call.meetingState()
        };
    }

    getCallObject() {
        return this.call;
    }

    on(eventName, handler) {
        if (!this.eventHandlers.has(eventName)) {
            this.eventHandlers.set(eventName, []);
        }
        this.eventHandlers.get(eventName).push(handler);
    }

    off(eventName, handler) {
        if (!this.eventHandlers.has(eventName)) return;

        const handlers = this.eventHandlers.get(eventName);
        const index = handlers.indexOf(handler);
        if (index > -1) {
            handlers.splice(index, 1);
        }
    }

    emitEvent(eventName, data) {
        if (!this.eventHandlers.has(eventName)) return;

        this.eventHandlers.get(eventName).forEach(handler => {
            try {
                handler(data);
            } catch (error) {
                console.error(`DailyManager: Error in event handler for ${eventName}:`, error);
            }
        });
    }

    destroy() {
        if (this.call) {
            this.call.destroy();
            this.call = null;
        }

        this.participants.clear();
        this.eventHandlers.clear();
        this.isInitialized = false;
        this.currentRoomUrl = null;

        // Reset singleton instance to allow recreation
        instance = null;
    }

    // Method to reinitialize if destroyed
    reinitialize() {
        if (!this.isInitialized) {
            this.init();
        }
    }
}

// Add a method to reset the singleton cache
export function resetDailyManager() {
    instance = null;
}

// NEW: Non-singleton function for creating multiple instances
export function createDailyManager(config = {}) {
    if (typeof window === 'undefined') {
        return null;
    }
    // Always create a new instance, bypassing singleton pattern
    return new DailyManager(config);
}

// Keep existing singleton function for main UI
let instance = null;
export function getDailyManager(config = {}) {
    if (typeof window === 'undefined') {
        return null;
    }
    if (!instance) {
        instance = new DailyManager(config);
    }
    return instance;
} 